install.packages("tm")
library(tm)
text_corpus<-Corpus(DirSource("500MNTNews"))
writeLines(as.character(text_corpus[[180]]))
text_corpus <- tm_map(text_corpus, stripWhitespace)
text_corpus <- tm_map(text_corpus, content_transformer(tolower))
text_corpus <- tm_map(text_corpus, removeWords, stopwords("english"))
text_corpus <- tm_map(text_corpus, removePunctuation)
text_corpus <- tm_map(text_corpus, stemDocument)
stopwords("english")

dtm <- DocumentTermMatrix(text_corpus)
dtm2 <- removeSparseTerms(dtm, sparse=0.95)
dtm3 <-DocumentTermMatrix(text_corpus, control=list(wordLengths=c(4, 20), bounds = list(global = c(5,200))))

dtm3
#LDA
k = 5;
SEED = 1234;
library(tm)

library(SnowballC)
library(topicmodels)
article.lda <- LDA(dtm3, k, method="Gibbs", control=list(seed = SEED))
lda.topics <- as.matrix(topics(article.lda))
lda.topics
lda.terms <- terms(article.lda)
lda.terms

findFreqTerms(dtm3, lowfreq = 200)
findFreqTerms(dtm3, lowfreq = 300)
freq <- sort(colSums(as.matrix(dtm3)), decreasing=TRUE)
freq
head(freq,10)
tail(freq,10)

m3<-as.matrix(dtm3)
df3<-as.data.frame(m3)
labels<-c(rep("dentistry",60),rep("depression",40),rep("diabetes",100))
labels<-as.factor(labels)
df3$label<-labels
str(df3)
entropy <- function(p) {
  # Assumes: p is a numeric vector
  if (sum(p) == 0) {
    return(0) 
  }
  p <- p/sum(p) # Normalize so it sums to 1
  p <- p[p > 0] # Discard zero entries (because 0 log 0 = 0)
  H = -sum(p*log(p,base=2))
  return(H)
}
entropy(c(20,5,6,7,9,10))
entropy(c(60,40,100))

surprise_dis<-df3[,"surpris"]
surprise_dis
shock_dis<-df3[,"shock"]
shock_dis