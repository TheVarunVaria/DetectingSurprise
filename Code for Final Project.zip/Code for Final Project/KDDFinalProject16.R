install.packages("tm")
library(tm)
setwd("/Users/thevarunvaria/Downloads")
text_corpus<-Corpus(DirSource("500MNTNews"))
writeLines(as.character(text_corpus[[180]]))
text_corpus <- tm_map(text_corpus, stripWhitespace)
text_corpus <- tm_map(text_corpus, content_transformer(tolower))
text_corpus <- tm_map(text_corpus, removeWords, stopwords("english"))
text_corpus <- tm_map(text_corpus, removePunctuation)

stopwords("english")

dtm <- DocumentTermMatrix(text_corpus)
dtm2 <- removeSparseTerms(dtm, sparse=0.95)
dtm3 <-DocumentTermMatrix(text_corpus, control=list(wordLengths=c(4, 20), bounds = list(global = c(5,200))))

dtm3

findFreqTerms(dtm3, lowfreq = 200)
findFreqTerms(dtm3, lowfreq = 300)
freq <- sort(colSums(as.matrix(dtm3)), decreasing=TRUE)
freq
head(freq,10)
tail(freq,10)

m3<-as.matrix(dtm3)
df3<-as.data.frame(m3)
labels<-c(rep("cancer",250),rep("depression",100),rep("diabetes",150))
labels<-as.factor(labels)
df3$label<-labels
str(df3)


# Calculate the entropy of a vector of counts or proportions
# Inputs: Vector of numbers
# Output: Entropy
entropy <- function(p) {
  # Assumes: p is a numeric vector
  if (sum(p) == 0) {
    return(0) 
  }
  p <- p/sum(p) # Normalize so it sums to 1
  p <- p[p > 0] # Discard zero entries (because 0 log 0 = 0)
  H = -sum(p*log(p,base=2))
  return(H)
}
entropy(c(20,5,6,7,9,10))
entropy(c(60,40,100))
entropy(c(250,100,150))



believe_dis<-df3[,"believe"]
believe_dis
surprise_dis<-df3[,"surprise"]
surprise_dis
know_dis<- df3[,"know"]
know_dis
assume_dis<-df3[,"assume"]
assume_dis
think_dis<-df3[,"think"]
think_dis
depression_dis<-df3[,"depression"]
depression_dis
diabetes_dis<-df3[,"diabetes"]
diabetes_dis
cancer_dis<-df3[,"cancer"]
cancer_dis

entropy(depression_dis)
entropy(human_dis)

# install.packages("infotheo")
library(infotheo)
mutinformation(believe_dis,know_dis,method="emp")

# identify those words with maximum MI with a particular word 
find_MI<-function(word,dataframe){
  word_dis<-dataframe[,word]
  
  lexicon <- colnames(dataframe)
  lexicon <- setdiff(lexicon,"label")
  vocab.size = length(lexicon)
  mis <- matrix(0,nrow=vocab.size,ncol=1)
  rownames(mis) = lexicon

  for (i in 1:vocab.size) {
  word2_dis<-dataframe[,lexicon[i]]
  mi<-mutinformation(word_dis,word2_dis,method="emp")
  
  mis[i,1]<-mi
  }
  
  return(mis)
}

food_MIs<-find_MI("know",df3)
food_MIs

row_numbers<-order(food_MIs[,1],decreasing = TRUE)
head(food_MIs[row_numbers,],10)



# Count how many documents in each class do or don’t contain a
# word
# Inputs: data matrix of word counts with class labels (BoW),
# word to check (word)
# Outputs: table of counts
word.class.indicator.counts <- function(dataframe,word) {
  # What are the classes?
  classes <- levels(dataframe[,"label"])
  # Prepare a matrix to store the counts, 1 row per class, 2 cols
  # (for present/absent)
  counts <- matrix(0,nrow=length(classes),ncol=2)
  # Name the rows to match the classes
  rownames(counts) = classes
  for (i in 1:length(classes)) {
    # Get a Boolean vector showing which rows belong to the class
    instance.rows = (dataframe[,"label"]==classes[i])
    # sum of a boolean vector is the number of TRUEs
    n.class = sum(instance.rows) # Number of class instances
    present = sum(dataframe[instance.rows,word] > 0)
    # present = Number of instances of class containing the word
    counts[i,1] = present
    counts[i,2] = n.class - present
  }
  return(counts)
}

important<-word.class.indicator.counts(df3,"cancer")

# Get the mutual information
# Inputs: array of indicator counts
# Calls: entropy()
# Outputs: mutual information
word.class.mutual.info <- function(counts) {
  # Assumes: counts is a numeric matrix
  # get the marginal entropy of the classes (rows) C
  marginal.entropy = entropy(rowSums(counts))
  # Get the probability of each value of X
  probs <- colSums(counts)/sum(counts)
  # Calculate the entropy of each column
  column.entropies = apply(counts,2,entropy)
  conditional.entropy = sum(probs*column.entropies)
  mutual.information = marginal.entropy - conditional.entropy
  return(mutual.information)
}

word.class.mutual.info(important)

# Calculate mutual information for each word
# Inputs: data frame of word counts with class labels
# Output: two-column matrix giving the mutual information of each word

# checking the word
  infos <- function(dataframe) {
  lexicon <- colnames(dataframe)
  # One of these columns will be class labels, that’s not a lexical item
  lexicon <- setdiff(lexicon,"label")
  vocab.size = length(lexicon)
  word.infos <- matrix(0,nrow=vocab.size,ncol=1)
  # Name the rows so we know what we’re talking about
  rownames(word.infos) = lexicon
  for (i in 1:vocab.size) {
    counts <- word.class.indicator.counts(dataframe,lexicon[i])
    word.infos[i,1] = word.class.mutual.info(counts)
  }
  return(word.infos)
  }
infos<-infos(df3)
head(infos,10)
row_numbers<-order(infos[,1],decreasing = TRUE)
head(infos[row_numbers,],10)

#topic modeling
# install.packages("topicmodels")
library(topicmodels)
dtm3
ap_lda <- LDA(dtm3, k = 4, control = list(seed = 1234))
ap_lda

# install.packages("tidytext")
library(tidytext)

# Word-Topic probabilities
ap_topics <- tidy(ap_lda, matrix = "beta")
ap_topics

# install.packages("ggplot2")
library(ggplot2)

# install.packages("dplyr")
library(dplyr)

# Visualization of the top 10 words for each topic
ap_top_terms <- ap_topics %>%
  group_by(topic) %>%
  top_n(10, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)

ap_top_terms %>%
  mutate(term = reorder(term, beta)) %>%
  ggplot(aes(term, beta, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  coord_flip()

#The words with the greatest differences among the three topics are visualized in Figure. We filter out those rare words (<1/1000).

# install.packages("tidyr")
library(tidyr)

beta_spread <- ap_topics %>%
  mutate(topic = paste0("topic", topic)) %>%
  spread(topic, beta) %>%
  filter(topic1 > .001 | topic2 > .001| topic3 > .001) %>%
  mutate(entropy = -topic1*log2(topic1)-topic2*log2(topic2)-topic3*log2(topic3))

beta_spread

beta_spread %>%
  top_n(-10, entropy) %>%
  mutate(term = reorder(term, entropy)) %>%
  ggplot(aes(term, entropy)) +
  geom_col() +
  labs(y = "entropy of terms over the three topics distribution") +
  coord_flip()

#Document-topic probabilities
library(tidytext)
ap_documents <- tidy(ap_lda, matrix = "gamma")
ap_documents

gamma_spread <- ap_documents %>%
  mutate(topic = paste0("topic", topic)) %>%
  spread(topic, gamma) 
